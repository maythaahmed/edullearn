﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;


namespace CapstoneFrontEnd.Models
{
    public class CapstoneDbContext : DbContext
    {
        public CapstoneDbContext(DbContextOptions<CapstoneDbContext> options) : base(options) { }

        public DbSet<SupportRequest> SupportRequests { get; set; }
        public DbSet<ContactFormModel> ContactForms { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SupportRequest>().HasData(
                new SupportRequest
                {
                    Id = 1,
                    FullName = "John Doe",
                    Email = "john.doe@example.com",
                    Message = "I need help with my account."
                }
            );

            modelBuilder.Entity<ContactFormModel>().HasData(
                new ContactFormModel
                {
                    Id = 1,
                    Name = "Alice Smith",
                    Email = "alice.smith@example.com",
                    Subject = "Feedback",
                    Message = "I love using your platform!"
                }
            );
        }
    }
}
