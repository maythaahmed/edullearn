﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace CapstoneFrontEnd.Models
{
    public class Policy : Controller
    {

            [Key] // Primary Key
            public int Id { get; set; }

            [Required]
            [StringLength(200)]
            public string Title { get; set; }

            [Required]
            public string Content { get; set; }
        }
    }

