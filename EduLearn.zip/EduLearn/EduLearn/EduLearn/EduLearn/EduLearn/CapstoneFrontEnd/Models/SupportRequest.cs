﻿using System.ComponentModel.DataAnnotations;

namespace CapstoneFrontEnd.Models
{
    public class SupportRequest
    {
        [Key]  // This defines the primary key
        public int Id { get; set; }
        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string Email { get; set; }

        [Required]
        [StringLength(500, ErrorMessage = "Message cannot exceed 500 characters.")]
        [Display(Name = "Your Message")]
        public string Message { get; set; }
    }
}



