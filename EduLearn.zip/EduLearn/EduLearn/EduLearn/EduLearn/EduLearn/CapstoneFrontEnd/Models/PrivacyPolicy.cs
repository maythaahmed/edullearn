﻿using Microsoft.AspNetCore.Mvc;

namespace CapstoneFrontEnd.Models
{
    public class PrivacyPolicy : Controller
    {
            public int Id { get; set; }  // Unique ID for each policy section
            public string Question { get; set; }  // The title of the policy question
            public string Answer { get; set; }  // The corresponding answer
        }
    }
