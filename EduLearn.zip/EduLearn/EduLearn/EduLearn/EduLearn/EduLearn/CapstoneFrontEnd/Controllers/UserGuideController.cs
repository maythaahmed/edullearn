﻿using Microsoft.AspNetCore.Mvc;
using CapstoneFrontEnd.Models;
using System.Linq;


namespace CapstoneFrontEnd.Controllers
{

    using Microsoft.AspNetCore.Mvc;

    namespace CapstoneFrontEnd.Controllers
    {
        public class UserGuideController : Controller
        {
            public IActionResult Index()
            {
                return View();
            }
        }
    }
}

   