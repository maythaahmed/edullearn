﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CapstoneFrontEnd.Controllers
{
    public class PoliciesController : Controller
    {

            private readonly ILogger<PoliciesController> _logger;

            // Simulated policy data (Replace with database integration later)
            private static List<Policy> _policies = new List<Policy>
        {
            new Policy { Id = 1, Title = "Terms of Service", Content = "By using the EduLearn platform, you agree to comply with the terms." },
            new Policy { Id = 2, Title = "Security & Compliance", Content = "We implement strong security measures to protect user data." },
            new Policy { Id = 3, Title = "Code of Conduct", Content = "All users must follow ethical guidelines to ensure a respectful learning environment." },
            new Policy { Id = 4, Title = "Refund & Cancellation Policy", Content = "Refund policies for paid courses are outlined here." },
            new Policy { Id = 5, Title = "Intellectual Property Rights", Content = "All platform content is protected under copyright laws." },
            new Policy { Id = 6, Title = "Legal Compliance", Content = "EduLearn follows all UAE laws and regulations." },
            new Policy { Id = 7, Title = "Policy Updates", Content = "EduLearn reserves the right to update policies at any time." },
            new Policy { Id = 8, Title = "Contact Us", Content = "For any inquiries regarding policies, please contact support@edulearn.com." }
        };

            public PoliciesController(ILogger<PoliciesController> logger)
            {
                _logger = logger;
            }

            // GET: Policies
            public IActionResult Index()
            {
                ViewData["Policies"] = _policies;
                return View();
            }

            // GET: Policies/List (API to fetch all policies)
            [HttpGet]
            public JsonResult GetPolicies()
            {
                return Json(_policies);
            }

            // GET: Policies/{id} (Fetch a single policy by ID)
            [HttpGet("Policies/{id}")]
            public IActionResult GetPolicy(int id)
            {
                var policy = _policies.FirstOrDefault(p => p.Id == id);
                if (policy == null)
                    return NotFound();

                return Json(policy);
            }

            // POST: Policies/Create (Add a new policy)
            [HttpPost]
            public IActionResult CreatePolicy([FromBody] Policy newPolicy)
            {
                if (newPolicy == null || string.IsNullOrEmpty(newPolicy.Title))
                    return BadRequest("Invalid policy data.");

                newPolicy.Id = _policies.Max(p => p.Id) + 1;
                _policies.Add(newPolicy);
                _logger.LogInformation($"New policy added: {newPolicy.Title}");

                return CreatedAtAction(nameof(GetPolicy), new { id = newPolicy.Id }, newPolicy);
            }

            // PUT: Policies/Update/{id} (Update an existing policy)
            [HttpPut("Policies/Update/{id}")]
            public IActionResult UpdatePolicy(int id, [FromBody] Policy updatedPolicy)
            {
                var policy = _policies.FirstOrDefault(p => p.Id == id);
                if (policy == null)
                    return NotFound();

                policy.Title = updatedPolicy.Title;
                policy.Content = updatedPolicy.Content;
                _logger.LogInformation($"Policy updated: {policy.Title}");

                return NoContent();
            }

            // DELETE: Policies/Delete/{id} (Remove a policy)
            [HttpDelete("Policies/Delete/{id}")]
            public IActionResult DeletePolicy(int id)
            {
                var policy = _policies.FirstOrDefault(p => p.Id == id);
                if (policy == null)
                    return NotFound();

                _policies.Remove(policy);
                _logger.LogInformation($"Policy deleted: {policy.Title}");

                return NoContent();
            }
        }

        // Policy model (Normally should be placed in a separate Models folder)
        public class Policy
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Content { get; set; }
        }
    }

