﻿using CapstoneFrontEnd.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace CapstoneFrontEnd.Controllers
{
    public class PrivacyController : Controller
    {
        public IActionResult Index()
        {
            // Simulated data for privacy policy sections
            var policies = new List<PrivacyPolicy>
            {
                new PrivacyPolicy { Id = 1, Question = "What information do we collect?", Answer = "We collect personal information such as name, email, and course preferences when you register for an account. We also gather usage data for analytics and improvements." },
                new PrivacyPolicy { Id = 2, Question = "How do we use your information?", Answer = "We use your data to provide personalized learning experiences, improve our platform, process transactions, and communicate important updates." },
                new PrivacyPolicy { Id = 3, Question = "Do we share your data with third parties?", Answer = "No, we do not sell or share your personal data with third parties, except as required by law or to provide services (such as payment processing)." },
                new PrivacyPolicy { Id = 4, Question = "How do we protect your data?", Answer = "We implement encryption, secure servers, and regular security audits to safeguard your personal data from unauthorized access." },
                new PrivacyPolicy { Id = 5, Question = "Can I delete my account and data?", Answer = "Yes, you can request account deletion by contacting our support team. Your data will be permanently removed from our system." },
                new PrivacyPolicy { Id = 6, Question = "Updates to this policy", Answer = "We may update this Privacy Policy from time to time. Changes will be posted on this page, and significant updates will be communicated via email." }
            };

            return View(policies);
        }
    }
}
