﻿using Microsoft.AspNetCore.Mvc;
using CapstoneFrontEnd.Models;

namespace CapstoneFrontEnd.Controllers
{
    public class SupportController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View(new SupportRequest());
        }

        [HttpPost]
        public IActionResult SubmitRequest(SupportRequest model)
        {
            return View("ThankYouSupport", model);
        }

        public IActionResult ThankYouSupport(SupportRequest model)
        {
            return View(model);
        }
    }
}

