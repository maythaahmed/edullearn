﻿using CapstoneFrontEnd.Models;
using Microsoft.AspNetCore.Mvc;

public class ContactController : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(ContactFormModel model)
    {

        return View("ThankYouForContact", model); // Return the form with validation errors
    }

    public IActionResult ThankYouForContact(ContactFormModel model)
    {
        return View(model);
    }

 
}

